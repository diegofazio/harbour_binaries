/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2104281802
#define HB_VER_CHLID             "4643587824552fd877e7f02ad11596e0b30c465d"
#define HB_VER_LENTRY            "2021-04-28 20:02 UTC+0200 Aleksander Czajczynski (hb fki.pl)"
#define HB_VER_HB_USER_CFLAGS    "-fPIC"
#define HB_PLATFORM              "linux"
#define HB_COMPILER              "gcc"
