# PdfClass
work with harupdf as a traditional report
