//
//  hb_bson_oid.h
//  hbmongoc
//
//  Created by Teo Fonrouge on 9/16/17.
//  Copyright © 2017 Teo Fonrouge. All rights reserved.
//

#ifndef hb_bson_oid_h
#define hb_bson_oid_h

#endif /* hb_bson_oid_h */
