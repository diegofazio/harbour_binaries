//
//  hb_mongoc_read_prefs.h
//  hbmongoc
//
//  Created by Teo Fonrouge on 9/7/17.
//  Copyright © 2017 Teo Fonrouge. All rights reserved.
//

#ifndef hb_mongoc_read_prefs_h
#define hb_mongoc_read_prefs_h

#endif /* hb_mongoc_read_prefs_h */
