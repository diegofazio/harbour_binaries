export ARCHITECTURE=linux
export PRG_COMPILER=XHARBOUR
export PRG_COMP_PATH=~/xharbour
export PRG_COMP_BIN_PATH=$PRG_COMP_PATH/bin
export PRG_COMP_LIB_PATH=$PRG_COMP_PATH/lib
export PRG_COMP_INC_PATH=$PRG_COMP_PATH/include
export C_COMPILER=gcc
export LIBNAME=libdolphin
export DOLPHIN_INC=./include
make
