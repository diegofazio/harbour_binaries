export ARCHITECTURE=linux
make clean
cd samples
make cleanall
cd ..
echo 'Done!!'
