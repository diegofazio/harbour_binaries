export ARCHITECTURE=linux
export PRG_COMPILER=HARBOUR
export PRG_COMP_PATH=/usr/local
export PRG_COMP_BIN_PATH=$PRG_COMP_PATH/bin
export PRG_COMP_LIB_PATH=$PRG_COMP_PATH/lib/harbour
export PRG_COMP_INC_PATH=$PRG_COMP_PATH/include/harbour
export C_COMPILER=gcc
export LIBNAME=libdolphin
export DOLPHIN_INC=./include
make
