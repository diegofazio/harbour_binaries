#!/bin/bash

hbmk2 nenadi.prg
hbmk2 ron.prg
hbmk2 test_dbf.prg
hbmk2 test_dbfe.prg
hbmk2 test_file.prg
hbmk2 test_filt.prg
hbmk2 test_ta.prg
hbmk2 test_tr.prg
hbmk2 test_var.prg
hbmk2 test_mem.prg -D__MEMIO__=1
hbmk2 letoudf
hbmk2 bug_info

